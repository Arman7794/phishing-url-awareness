# EWB Phishing URL Awareness Checker

## 1. Project overview

The Phishing URL Awareness Checker is a beginner-friendly Python command-line
project. It checks the visible text of a URL for selected warning signs that
may be associated with phishing. It does not visit websites, make network
requests, or decide whether a website is safe.

## 2. Features

The program checks for:
- An `@` symbol in the URL.
- A URL longer than 100 characters.
- An IP address used as the hostname.
- Five or more hostname segments.
- A punycode-style hostname marker (`xn--`).
- The HTTP scheme.

It also handles blank and malformed input and allows the user to inspect
multiple sample URLs until they choose to quit.

## 3. Improvements included

1. **Repeat-and-quit menu:** users can check multiple sample URLs in one run
   and type `q` to exit.
2. **Malformed URL handling:** invalid URL input is handled without an
   unhandled parsing error.
3. **Clear result summary:** the program reminds users to review URLs
   carefully and explains that no warning signs does not prove safety.

## 4. Requirements

- Python 3.10 or later.
- No third-party Python packages are required.

## 5. Project structure

```text
phishing-url-awareness/
├── phishing_checker.py
├── README.md
├── requirements.txt
├── tests/
│   └── test_samples.md
└── screenshots/
    └── README.txt
```

## 6. How to run on Windows

1. Install Python 3.10 or later from https://www.python.org/downloads/.
2. During installation, select **Add Python to PATH**.
3. Extract this project ZIP file.
4. Open the extracted `phishing-url-awareness` folder.
5. Click the folder address bar, type `cmd`, and press Enter.
6. Check Python is available by running:

   ```bash
   python --version
   ```

7. Start the program:

   ```bash
   python phishing_checker.py
   ```

8. Enter one of the sample URLs from `tests/test_samples.md`.
9. Type `q` when you want to exit.

## 7. Example output

```text
EWB Phishing URL Awareness Checker
Text checks only - this program does not open URLs.

Enter a sample URL to inspect (or type q to quit):
http://192.0.2.10/account

Result:
- Uses an IP address instead of a familiar domain.
- Uses HTTP. HTTPS alone does not prove trust.

Overall: Review carefully. These are warning signs, not a verdict.
```

## 8. Testing

Five required sample cases and additional checks are documented in
[`tests/test_samples.md`](tests/test_samples.md). Run each sample on your
computer and confirm the program's output. The expected results are included
in that file.

## 9. Screenshots / evidence

Capture genuine screenshots from your own Windows laptop after running the
program. Save them in the `screenshots` folder using these exact names:

- `sample_run.png` — show the program running with a sample URL and its result.
- `test_results.png` — show the test cases/results, for example the test table
  open in a text editor or the terminal showing the test runs.

Do not submit illustrative images as proof of execution. See
[`screenshots/README.txt`](screenshots/README.txt) for capture instructions.

## 10. Limitations

- The checker examines URL text only.
- It does not open URLs or contact websites.
- It checks only the warning signs listed above.
- A URL with no detected warning signs may still be malicious.
- HTTPS does not guarantee that a website is trustworthy.
- Results are educational indicators, not a security verdict.

## 11. Ethical use

Use harmless sample strings for learning and awareness. Do not use this tool
to collect credentials, probe websites, scan live systems, or encourage
anyone to visit suspicious links.

## 12. Author

Add your name and student details here before submission.
