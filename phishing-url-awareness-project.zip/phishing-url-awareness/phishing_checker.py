"""
EWB Phishing URL Awareness Checker
Text-only educational checker. It does not open URLs or make network requests.
Python 3.10+
"""

import ipaddress
from urllib.parse import urlparse


def inspect_url(raw_url):
    """Check visible URL text for selected warning signs."""
    url = raw_url.strip()
    findings = []

    if not url:
        return ["No URL entered."]

    candidate = url if "://" in url else "http://" + url

    try:
        parsed = urlparse(candidate)
        host = (parsed.hostname or "").lower()
    except ValueError:
        return ["Malformed URL. Could not safely parse the hostname."]

    if not host:
        return ["Could not identify a hostname."]

    if "@" in candidate:
        findings.append("Contains an @ symbol; inspect carefully.")

    if len(url) > 100:
        findings.append("Unusually long URL (over 100 characters).")

    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        is_ip = False

    if is_ip and "." in host:
        findings.append("Uses an IP address instead of a familiar domain.")

    labels = [part for part in host.split(".") if part]
    if len(labels) >= 5:
        findings.append("Contains many hostname segments/subdomains.")

    if "xn--" in host:
        findings.append("Contains a punycode-style hostname.")

    if parsed.scheme.lower() == "http":
        findings.append("Uses HTTP. HTTPS alone does not prove trust.")

    if not findings:
        findings.append(
            "No listed warning signs found. This does NOT prove safety."
        )

    return findings


def main():
    print("=" * 48)
    print("EWB Phishing URL Awareness Checker")
    print("Text checks only - this program does not open URLs.")
    print("=" * 48)

    while True:
        raw_url = input("\nEnter a sample URL to inspect (or type q to quit): ")

        if raw_url.strip().lower() in {"q", "quit", "exit"}:
            print("Exiting. Stay alert and never enter passwords from unexpected links.")
            break

        findings = inspect_url(raw_url)

        print("\nResult:")
        for item in findings:
            print("- " + item)

        if findings == ["No listed warning signs found. This does NOT prove safety."]:
            print("\nOverall: No selected warning signs detected; still review carefully.")
        elif findings == ["No URL entered."]:
            print("\nOverall: Please enter a URL to inspect.")
        else:
            print("\nOverall: Review carefully. These are warning signs, not a verdict.")

        print("\nReminder: A URL checker cannot guarantee that a website is safe.")


if __name__ == "__main__":
    main()
