SCREENSHOT EVIDENCE INSTRUCTIONS

This folder is intentionally supplied without fabricated evidence screenshots.
After you run the project on your own Windows laptop, save two genuine screenshots
here:

1. sample_run.png
   - Open Command Prompt in the project folder.
   - Run: python phishing_checker.py
   - Enter: http://192.0.2.10/account
   - Capture the terminal showing the warnings.

2. test_results.png
   - Open tests/test_samples.md in Notepad or VS Code.
   - Capture the five sample cases and expected results, or capture your own
     terminal test runs.
   - Save the screenshot with this exact filename.

Use Windows Snipping Tool (Win + Shift + S), then save the captured image in
this folder. Do not use a mockup as proof that you ran the program.
