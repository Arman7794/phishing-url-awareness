# Test Samples and Results

Run the program with `python phishing_checker.py` and compare the output with
the expected results below. These tests inspect URL text only; do not open the
sample URLs in a browser.

| # | Sample input | Expected findings | Result |
|---|---|---|---|
| 1 | `https://www.example.com/login` | No listed warning signs found; this does NOT prove safety. | PASS |
| 2 | `http://192.0.2.10/account` | IP address warning; HTTP warning. | PASS |
| 3 | `http://example.com@sample.invalid/login` | `@` symbol warning; HTTP warning. | PASS |
| 4 | `https://a.b.c.d.e.example.invalid/path` | Many hostname segments/subdomains warning. | PASS |
| 5 | `https://xn--example.invalid/` | Punycode-style hostname warning. | PASS |

## Additional checks

- Blank input: displays `No URL entered.`
- `www.example.com`: treated as HTTP for checking and displays an HTTP warning.
- `https://secure-login.example.invalid`: may show no selected warning signs;
  this does not mean it is safe.
- `http://[bad`: handled as a malformed URL without crashing.
- Type `q` at the prompt: exits the program.

**Important:** The PASS labels above describe the expected behaviour of the
provided implementation. Run the tests on your own laptop and capture your
actual terminal output for submission evidence.
